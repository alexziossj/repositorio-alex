from django.shortcuts import render
import requests
from django.shortcuts import render
import hashlib
import time

def search_characters(request):
    query = request.GET.get('query', '')
    characters = []
    if query:
        url = f'http://gateway.marvel.com:80/v1/public/characters?name={query}'
        api_key = '395118412dfa9f806dadba9d1df7fa5c'  
        private_key = '26866ccabdb3ff909e46a5bfd0f35d06506a643e'
        ts = str(int(time.time()))
        hash_str = ts + private_key + api_key
        hash_md5 = hashlib.md5(hash_str.encode()).hexdigest()
        params = {
        'ts': ts,
        'apikey': api_key,
        'hash': hash_md5
        }
        response = requests.get(url,params=params)
        if response.status_code == 200:
            characters = response.json()
            characters= characters['data']['results']
            
        
    return render(request, 'characters/search.html', {'characters': characters, 'query': query})
# Create your views here.
